export interface IProduto {
    nome: string
    preco: number
}