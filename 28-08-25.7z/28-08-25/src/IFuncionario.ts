export interface IFuncionario {
    nome: string;
    cargo: string;
    salario: number;
}