export interface FormaGeometrica {
    calcularArea(): number;
}