interface IAnimal {
    nome: string;
    raca: string;
    
    emitirSom(): void;
}