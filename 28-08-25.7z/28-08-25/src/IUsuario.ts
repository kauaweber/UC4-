// Crio a interface Usuario
// qualquer objeto ou classe que implemente/use esta interface PRECISA seguir as regras dela, ou seja, ter todos os seus atributos, tipos e metodos (se hover)
export interface IUsuario {
    nome: string 
    idade: number
}