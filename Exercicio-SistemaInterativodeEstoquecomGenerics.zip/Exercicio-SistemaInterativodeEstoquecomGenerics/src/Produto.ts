export interface Produto {
    preco: number;
    exibir(): string;
  }
  